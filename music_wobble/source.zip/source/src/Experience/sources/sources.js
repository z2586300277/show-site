export default [
  {
    name: 'environmentTexture',
    type: 'hdri',
    path: 'https://z2586300277.github.io/3d-file-server/files/hdr/1k.hdr',
  }
];
